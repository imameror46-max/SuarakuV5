package com.suaraku.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Quality(val label: String, val rate: Int, val bits: Int, val note: String) {
    val mbPerMin get() = rate * (bits / 8) * 60 / 1_000_000.0
}

val QUALITIES = listOf(
    Quality("48 kHz • 24-bit", 48000, 24, "Maksimal yang berguna untuk dubbing YouTube (disarankan)."),
    Quality("48 kHz • 16-bit", 48000, 16, "Standar video/YouTube, file lebih kecil."),
    Quality("44,1 kHz • 16-bit", 44100, 16, "Standar CD/musik."),
    Quality("96 kHz • 24-bit", 96000, 24, "Studio. Tidak perlu untuk YouTube, file besar, tidak semua HP/mic mendukung."),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun Pick(text: String, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val pad = PaddingValues(horizontal = 14.dp)
    if (selected) Button(onClick = onClick, enabled = enabled, contentPadding = pad) { Text(text, maxLines = 1) }
    else FilledTonalButton(onClick = onClick, enabled = enabled, contentPadding = pad) { Text(text, maxLines = 1) }
}

fun defaultName(): String = "Rekaman_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

fun describe(f: File): String = try {
    RandomAccessFile(f, "r").use { r ->
        val h = ByteArray(44)
        r.readFully(h)
        val bb = ByteBuffer.wrap(h).order(ByteOrder.LITTLE_ENDIAN)
        val rate = bb.getInt(24)
        val bits = bb.getShort(34).toInt()
        val sec = ((r.length() - 44) / (rate * (bits / 8L))).toInt()
        String.format("%.1f kHz • %d-bit • %d:%02d • %.1f MB", rate / 1000.0, bits, sec / 60, sec % 60, r.length() / 1e6)
    }
} catch (e: Throwable) { "" }

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("suaraku", 0) }
    val takeFile = remember { File(ctx.cacheDir, "rekaman.wav") }
    var qi by remember { mutableStateOf(prefs.getInt("q", 0).coerceIn(0, QUALITIES.size - 1)) }
    val q = QUALITIES[qi]
    var folder by remember { mutableStateOf(prefs.getString("folder", null)?.let { Uri.parse(it) }) }
    var hasTake by remember { mutableStateOf(takeFile.exists() && takeFile.length() > 44) }
    var saved by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(defaultName()) }
    var takeInfo by remember { mutableStateOf(if (hasTake) describe(takeFile) else "") }
    var status by remember { mutableStateOf("") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playing by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmOverwrite by remember { mutableStateOf(false) }
    var pendingSave by remember { mutableStateOf(false) }

    DisposableEffect(Unit) { onDispose { player?.release() } }

    fun stopPlayer() { player?.release(); player = null; playing = false }

    LaunchedEffect(RecState.recording) {
        if (RecState.recording) { stopPlayer(); hasTake = false; saved = false }
    }
    LaunchedEffect(RecState.finished) {
        if (RecState.finished > 0) {
            hasTake = takeFile.exists() && takeFile.length() > 44
            if (hasTake) { name = defaultName(); saved = false; takeInfo = describe(takeFile); status = "Rekaman selesai. Beri nama lalu simpan, atau hapus." }
        }
    }

    fun folderLabel(u: Uri): String =
        Uri.decode(DocumentsContract.getTreeDocumentId(u)).replace("primary:", "Penyimpanan internal/")

    fun cleanName(n: String): String {
        val c = n.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").removeSuffix(".wav").trim()
        return if (c.isEmpty()) defaultName() else c
    }

    fun doSave() {
        val tree = folder ?: return
        val fname = cleanName(name) + ".wav"
        try {
            val dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
            val dst = DocumentsContract.createDocument(ctx.contentResolver, dir, "audio/x-wav", fname)
            if (dst == null) { status = "Gagal membuat file di folder itu. Pilih folder lagi."; return }
            ctx.contentResolver.openOutputStream(dst)?.use { o -> takeFile.inputStream().use { it.copyTo(o) } }
            saved = true
            status = "Tersimpan: ${folderLabel(tree)}/$fname"
        } catch (t: Throwable) {
            status = "Gagal menyimpan: ${t.message}. Coba pilih folder lagi."
        }
    }

    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            ctx.contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            prefs.edit().putString("folder", u.toString()).apply()
            folder = u
            if (pendingSave) { pendingSave = false; doSave() }
        } else pendingSave = false
    }

    fun beginRecord() {
        RecState.error = null
        status = "Memulai rekaman…"
        val i = Intent(ctx, RecordService::class.java).setAction(RecordService.ACTION_START)
            .putExtra("rate", q.rate).putExtra("bits", q.bits)
        ContextCompat.startForegroundService(ctx, i)
    }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true) beginRecord() else status = "Izin mikrofon ditolak."
    }

    fun requestAndStart() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginRecord()
        else {
            val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            perm.launch(need.toTypedArray())
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Hapus rekaman ini?") },
        text = { Text("Rekaman yang baru direkam akan dihapus permanen.") },
        confirmButton = {
            TextButton(onClick = {
                stopPlayer(); takeFile.delete(); hasTake = false; saved = false
                confirmDelete = false; status = "Rekaman dihapus."
            }) { Text("Hapus") }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Batal") } }
    )
    if (confirmOverwrite) AlertDialog(
        onDismissRequest = { confirmOverwrite = false },
        title = { Text("Rekaman sebelumnya belum disimpan") },
        text = { Text("Mulai rekaman baru akan menimpa rekaman sebelumnya.") },
        confirmButton = { TextButton(onClick = { confirmOverwrite = false; requestAndStart() }) { Text("Timpa & rekam") } },
        dismissButton = { TextButton(onClick = { confirmOverwrite = false }) { Text("Batal") } }
    )

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Voice Recorder by IMS", style = MaterialTheme.typography.headlineMedium)

        Text("Kualitas rekaman", style = MaterialTheme.typography.titleMedium)
        QUALITIES.forEachIndexed { i, qq ->
            Pick(qq.label, i == qi, enabled = !RecState.recording) { qi = i; prefs.edit().putInt("q", i).apply() }
        }
        Text("${q.note}  Ukuran sekitar ${String.format("%.1f", q.mbPerMin)} MB per menit (mono, WAV tanpa kompresi).")

        LinearProgressIndicator(progress = { RecState.level }, modifier = Modifier.fillMaxWidth())
        Text(
            "%d:%02d".format(RecState.seconds / 60, RecState.seconds % 60) +
                (if (RecState.level > 0.97f) "   PECAH! kecilkan volume / jauhkan mic" else "")
        )
        RecState.error?.let { Text(it) }
        Button(
            onClick = {
                if (RecState.recording) RecState.recorder?.stop()
                else if (hasTake && !saved) confirmOverwrite = true
                else requestAndStart()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (RecState.recording) "Berhenti" else "Mulai rekam") }
        Text("Rekaman tetap berjalan saat layar mati atau pindah aplikasi (muncul notifikasi). Maksimal 60 menit.")

        if (hasTake && !RecState.recording) {
            Text("Hasil rekaman terakhir", style = MaterialTheme.typography.titleMedium)
            if (takeInfo.isNotEmpty()) Text(takeInfo)
            OutlinedTextField(
                value = name, onValueChange = { name = it; saved = false },
                label = { Text("Nama file (tanpa .wav)") }, singleLine = true, modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pick(if (playing) "Berhenti putar" else "Putar", false) {
                    if (playing) stopPlayer() else try {
                        player = MediaPlayer().apply {
                            setDataSource(takeFile.path); prepare()
                            setOnCompletionListener { playing = false }
                            start()
                        }
                        playing = true
                    } catch (t: Throwable) {
                        status = "Preview tidak bisa diputar di HP ini (file tetap valid): ${t.message}"
                    }
                }
                Pick(if (saved) "Simpan lagi" else "Simpan", true) {
                    if (folder == null) { pendingSave = true; pickFolder.launch(null) } else doSave()
                }
                Pick("Hapus", false) { confirmDelete = true }
            }
        }

        Text("Folder simpan", style = MaterialTheme.typography.titleMedium)
        Text(folder?.let { folderLabel(it) } ?: "Belum dipilih (akan ditanya saat menyimpan)")
        Pick(if (folder == null) "Pilih folder" else "Ganti folder", false) { pickFolder.launch(null) }

        if (status.isNotEmpty()) Text(status)
    }
}
