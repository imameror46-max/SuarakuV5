package com.suaraku.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import java.io.File

/** Service latar depan supaya rekaman tetap jalan saat layar mati / pindah aplikasi. */
class RecordService : Service() {
    companion object { const val ACTION_START = "com.suaraku.app.START" }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) begin(intent.getIntExtra("rate", 48000), intent.getIntExtra("bits", 16))
        else stopSelf()
        return START_NOT_STICKY
    }

    private fun begin(rate: Int, bits: Int) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Perekaman", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "rec")
            .setContentTitle("SuaraKu merekam")
            .setContentText("Rekaman sedang berjalan")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)

        if (RecState.recording) return
        val main = Handler(Looper.getMainLooper())
        val r = WavRecorder(rate, bits, File(cacheDir, "rekaman.wav"), 3600,
            { RecState.level = it }, { RecState.seconds = it }) {
            main.post {
                RecState.recording = false
                RecState.level = 0f
                RecState.finished = RecState.finished + 1
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        if (r.start(this)) {
            RecState.recorder = r
            RecState.seconds = 0
            RecState.recording = true
        } else {
            RecState.error = r.error
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }
}
