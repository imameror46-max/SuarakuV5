package com.suaraku.app

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max

/** Status perekaman yang dibaca oleh layar. */
object RecState {
    var recording by mutableStateOf(false)
    var level by mutableStateOf(0f)
    var seconds by mutableStateOf(0)
    var error by mutableStateOf<String?>(null)
    var finished by mutableStateOf(0)
    @Volatile var recorder: WavRecorder? = null
}

/** Perekam WAV PCM mono 16-bit / 24-bit tanpa kompresi. */
class WavRecorder(
    private val rate: Int,
    private val bits: Int,
    private val file: File,
    private val maxSeconds: Int,
    private val onLevel: (Float) -> Unit,
    private val onTime: (Int) -> Unit,
    private val onDone: () -> Unit
) {
    @Volatile private var running = false
    var error: String? = null

    @SuppressLint("MissingPermission")
    fun start(ctx: Context): Boolean {
        val enc = if (bits == 24) {
            if (Build.VERSION.SDK_INT < 31) { error = "24-bit membutuhkan Android 12 ke atas"; return false }
            AudioFormat.ENCODING_PCM_24BIT_PACKED
        } else AudioFormat.ENCODING_PCM_16BIT
        val bps = bits / 8
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val unprocessed = am.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
        val src = if (unprocessed) MediaRecorder.AudioSource.UNPROCESSED else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, enc)
        if (minBuf <= 0) { error = "Kualitas $rate Hz / $bits-bit tidak didukung HP atau mic ini"; return false }
        val rec = try {
            AudioRecord.Builder()
                .setAudioSource(src)
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(enc).setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
                )
                .setBufferSizeInBytes(max(minBuf * 4, rate * bps))
                .build()
        } catch (t: Throwable) { error = "Mikrofon tidak bisa dibuka: ${t.message}"; return false }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release(); error = "Kualitas $rate Hz / $bits-bit tidak didukung HP atau mic ini"; return false
        }
        running = true
        Thread {
            var total = 0L
            var raf: RandomAccessFile? = null
            try {
                raf = RandomAccessFile(file, "rw")
                raf.setLength(0)
                raf.write(ByteArray(44))
                val bytes = ByteArray(rate / 20 * bps)
                rec.startRecording()
                while (running && total < rate.toLong() * maxSeconds) {
                    val n = rec.read(bytes, 0, bytes.size)
                    if (n < 0) { RecState.error = "Perekaman terhenti (kode $n)"; break }
                    if (n == 0) continue
                    var peak = 0
                    var i = 0
                    while (i + bps <= n) {
                        val s = if (bits == 16)
                            (bytes[i + 1].toInt() shl 8) or (bytes[i].toInt() and 0xFF)
                        else
                            (bytes[i + 2].toInt() shl 16) or ((bytes[i + 1].toInt() and 0xFF) shl 8) or (bytes[i].toInt() and 0xFF)
                        val a = abs(s)
                        if (a > peak) peak = a
                        i += bps
                    }
                    raf.write(bytes, 0, n)
                    total += n / bps
                    onLevel(peak / (if (bits == 16) 32768f else 8388608f))
                    onTime((total / rate).toInt())
                }
            } catch (t: Throwable) {
                RecState.error = "Gagal merekam: ${t.message}"
            } finally {
                try { rec.stop() } catch (_: Throwable) {}
                rec.release()
                try {
                    val dataBytes = (total * bps).toInt()
                    val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray()).putInt(36 + dataBytes).put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(1)
                    h.putInt(rate).putInt(rate * bps).putShort(bps.toShort()).putShort(bits.toShort())
                    h.put("data".toByteArray()).putInt(dataBytes)
                    raf?.seek(0); raf?.write(h.array()); raf?.close()
                } catch (_: Throwable) {}
                running = false
                onDone()
            }
        }.start()
        return true
    }

    fun stop() { running = false }
}
